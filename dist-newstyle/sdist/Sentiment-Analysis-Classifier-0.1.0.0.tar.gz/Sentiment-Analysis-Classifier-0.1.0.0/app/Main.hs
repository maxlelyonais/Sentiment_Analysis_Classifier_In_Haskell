{-# LANGUAGE DeriveGeneric #-}
{-# LANGUAGE OverloadedStrings #-}


module Main where
{-# OPTIONS_GHC -package bytestring #-}

import Data.Aeson
import GHC.Generics
import qualified Data.ByteString.Lazy as BS
import qualified Data.ByteString.Char8 as BSC

data Reviewer = Reviewer
                {
                    reviewerID :: String
                    ,reviewText :: String
                    ,overall :: String
                } deriving( Show, Generic)

instance FromJSON Reviewer

load :: IO (Maybe Reviewer)
load = do
        json <- BS.readFile "reviews_Video_GamesFinal.json"
        putStrLn "RAW JSON:"
        putStrLn $ BSC.unpack json
        return (decode json)

main :: IO ()
main = do
    maybeReviewer <- load
    case maybeReviewer of
        Just reviewer -> print reviewer
        Nothing       -> putStrLn "Fail to load and parse JSON"



